document.addEventListener("alpine:init", () => {
  Alpine.data("products", () => ({
    items: [
      {
        id: 1,
        name: "Perfume",
        img: "../img/parfum1.jpg",
        price: 2050000,
        caption: "35ml - Intense Floral, Fruity and Woody Notes",
      },
      {
        id: 2,
        name: "Eau de Parfum",
        img: "../img/parfum2.webp",
        price: 2400000,
        caption: "50ml - Floral and Fresh Notes",
      },
      {
        id: 3,
        name: "Eau de Toilette",
        img: "../img/parfum3.webp",
        price: 1950000,
        caption: "50ml - Fresh and Tender Notes",
      },
    ],
    showModal: false,
    selectedProduct: {},
    openModal(item) {
      this.selectedProduct = item;
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    },
  }));

  Alpine.store("cart", {
    items: [],
    total: 0,
    quantity: 0,
    add(newItem) {
      // Check availability
      const cartItem = this.items.find((item) => item.id === newItem.id);

      // If empty
      if (!cartItem) {
        this.items.push({ ...newItem, quantity: 1, total: newItem.price });
        this.quantity++;
        this.total += newItem.price;
      } else {
        this.items = this.items.map((item) => {
          if (item.id !== newItem.id) {
            return item;
          } else {
            item.quantity++;
            item.total = item.price * item.quantity;
            this.quantity++;
            this.total += item.price;
            return item;
          }
        });
      }
    },

    remove(id) {
      const cartItem = this.items.find((item) => item.id === id);

      if (cartItem.quantity > 1) {
        this.items = this.items.map((item) => {
          if (item.id !== id) {
            return item;
          } else {
            item.quantity--;
            item.total = item.price * item.quantity;
            this.quantity--;
            this.total -= item.price;
            return item;
          }
        });
      } else if (cartItem.quantity === 1) {
        this.items = this.items.filter((item) => item.id !== id);
        this.quantity--;
        this.total -= cartItem.price;
      }
    },
  });
});

//form validation
const coButton = document.querySelector(".co-button");
coButton.disabled = true;

const form = document.querySelector("#coform");
form.addEventListener("keyup", function () {
  for (let i = 0; i < form.elements.length; i++) {
    if (form.elements[i].value.length !== 0) {
      coButton.classList.remove("disabled");
      coButton.classList.add("disabled");
    } else {
      return false;
    }
  }
  coButton.disabled = false;
  coButton.classList.remove("disabled");
});

//send data waktu click co
coButton.addEventListener("click", function (e) {
  e.preventDefault();
  const formData = new FormData(form);
  const data = new URLSearchParams(formData);
  const objData = Object.fromEntries(data);
  const msg = formatmsg(objData);
  window.open("http://wa.me/6281266378385?text=" + encodeURIComponent(msg));
});

//wassap
const formatmsg = (obj) => {
  return `Data Customer
    Nama: ${obj.name}
    Email: ${obj.email}
    No Hp: ${obj.phone}
    Data Pesanan ${JSON.parse(obj.items).map(
      (item) => `${item.name} (${item.quantity} x ${rp(item.total)})\n`
    )}
    TOTAL: #{rp(obj.total)}
    Thank you.`;
};

//konversi moneyy
const rp = (number) => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(number);
};
